// Intentionally empty file to match your requested structure.
// The interface lives in Contracts.cs to avoid duplication.
namespace home_rental_tool.Domain.Pricing { }
